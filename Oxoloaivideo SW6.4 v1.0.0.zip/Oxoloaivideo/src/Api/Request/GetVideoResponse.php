<?php declare(strict_types=1);

namespace Oxoloaivideo\Api\Request;

class GetVideoResponse
{
    private ?string $link = null;
    private ?string $thumbnail = null;
    private string $status;

    public function __construct(?string $link, ?string $thumbnail, string $status)
    {
        $this->link = $link;
        $this->thumbnail = $thumbnail;
        $this->status = $status;
    }

    public function getLink(): ?string
    {
        return $this->link;
    }

    public function setLink(?string $link): void
    {
        $this->link = $link;
    }

    public function getThumbnail(): ?string
    {
        return $this->thumbnail;
    }

    public function setThumbnail(?string $thumbnail): void
    {
        $this->thumbnail = $thumbnail;
    }

    public function getStatus(): string
    {
        return $this->status;
    }

    public function setStatus(string $status): void
    {
        $this->status = $status;
    }
}
