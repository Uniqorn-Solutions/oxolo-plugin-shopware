<?php declare(strict_types=1);

namespace Oxoloaivideo\Service\Exception;

use Shopware\Core\Framework\ShopwareHttpException;
use Symfony\Component\HttpFoundation\Response;

class VideoExistsException extends ShopwareHttpException
{
    private string $oxoloVideoId;

    public function __construct(string $oxoloOxoloVideoId)
    {
        $this->$oxoloOxoloVideoId = $oxoloOxoloVideoId;

        parent::__construct(
            'Video with Oxolo ID {{ oxoloVideoId }} exists.',
            ['oxoloVideoId' => $oxoloOxoloVideoId]
        );
    }

    public function getOxoloVideoId(): string
    {
        return $this->oxoloVideoId;
    }

    public function getErrorCode(): string
    {
        return 'OXOLOAIVIDEO__VIDEO_EXISTS';
    }

    public function getStatusCode(): int
    {
        return Response::HTTP_BAD_REQUEST;
    }
}
