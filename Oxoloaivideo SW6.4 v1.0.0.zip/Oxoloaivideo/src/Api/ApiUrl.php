<?php declare(strict_types=1);

namespace Oxoloaivideo\Api;

final class ApiUrl
{
    public const BASE_URL_LIVE = 'https://oxolo-plugin-middleware.uniqorn.solutions/api/v1/';
    public const BASE_URL_TEST = 'https://api.oxolo.middleware.9span.in/api/v1/';

    public const CREATE_MEDIA = 'asset/upload';
    public const CREATE_VIDEO = 'video/product';
    public const CREATE_WEBHOOK = 'webhook';
    public const GET_CATALOG = 'catalogue/{catalogId}';
    public const GET_CATALOGS = 'catalogue';
    public const GET_CREDITS = 'account/credits';
    public const GET_VIDEO = 'video/{videoId}';
    public const REGISTER_USER = 'plugin/user-register';
}
