<?php declare(strict_types=1);

namespace Oxoloaivideo;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Exception;
use Oxoloaivideo\Lifecycle\Installer;
use Oxoloaivideo\Lifecycle\Uninstaller;
use Shopware\Core\Framework\Plugin;
use Shopware\Core\Framework\Plugin\Context\InstallContext;
use Shopware\Core\Framework\Plugin\Context\UninstallContext;
use Shopware\Core\System\SystemConfig\SystemConfigService;

class Oxoloaivideo extends Plugin
{
    public function install(InstallContext $installContext): void
    {
        $this->getInstaller()->install();

        parent::install($installContext);
    }


    /**
     * @throws Exception
     */
    public function uninstall(UninstallContext $uninstallContext): void
    {
        if (!$uninstallContext->keepUserData()) {
            $this->getUninstaller()->uninstall();
        }

        parent::uninstall($uninstallContext);
    }

    private function getInstaller(): Installer
    {
        $systemConfigService = $this->container->get(SystemConfigService::class);

        return new Installer($systemConfigService);
    }

    private function getUninstaller(): Uninstaller
    {
        $connection = $this->container->get(Connection::class);

        return new Uninstaller($connection);
    }
}
