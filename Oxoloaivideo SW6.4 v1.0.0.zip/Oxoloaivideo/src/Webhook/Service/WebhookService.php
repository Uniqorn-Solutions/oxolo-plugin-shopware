<?php declare(strict_types=1);

namespace Oxoloaivideo\Webhook\Service;

use Oxoloaivideo\Api\Exception\ApiException;
use Oxoloaivideo\Api\Gateway;
use Oxoloaivideo\Api\RequestFactory;
use Oxoloaivideo\Entity\OxoloVideoEntity;
use Oxoloaivideo\Webhook\Exception\VideoNotFoundException;
use Oxoloaivideo\Webhook\MesssageQueue\DownloadOxoloVideo;
use Oxoloaivideo\Webhook\Struct\Notification;
use Psr\Log\LoggerInterface;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\System\SystemConfig\SystemConfigService;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\Messenger\MessageBusInterface;

class WebhookService
{
    private RequestFactory $requestFactory;
    private Gateway $gateway;
    private LoggerInterface $logger;
    private SystemConfigService $systemConfigService;
    private EntityRepository $videoRepository;
    private MessageBusInterface $messageBus;

    public function __construct(
        RequestFactory $requestFactory,
        Gateway $gateway,
        LoggerInterface $logger,
        SystemConfigService $systemConfigService,
        EntityRepository $videoRepository,
        MessageBusInterface $messageBus
    ) {
        $this->requestFactory = $requestFactory;
        $this->gateway = $gateway;
        $this->logger = $logger;
        $this->systemConfigService = $systemConfigService;
        $this->videoRepository = $videoRepository;
        $this->messageBus = $messageBus;
    }

    /**
     * @throws ApiException
     */
    public function createWebhook(): void
    {
        $createWebhookRequest = $this->requestFactory->createWebhookRequest();

        $this->gateway->registerUser();
        $this->gateway->createWebhook($createWebhookRequest);
    }

    public function handleNotification(Request $request, Context $context): void
    {
        $this->logger->info(
            'Received webhook notification.',
            ['content' => $request->getContent()],
        );

        $notification = Notification::fromRequest($request);
        $this->validateNotification($notification);

        if ($notification->getProgress() != 100) {
            // ignore videos in progress
            return;
        }

        $video = $this->getVideo($notification->getOxoloVideoId(), $context);
        $this->messageBus->dispatch(new DownloadOxoloVideo($video->getId(), $video->getOxoloId()));
    }

    public function validateNotification(Notification $notification): void
    {
        $token = $this->systemConfigService->get('Oxoloaivideo.config.webhookToken');

        if (!$token || $notification->getToken() !== $token) {
            throw new AccessDeniedHttpException();
        }
        if ($notification->getOxoloVideoId() === null) {
            throw new BadRequestHttpException('Required parameter "videoId" is missing.');
        }
        if ($notification->getProgress() === null) {
            throw new BadRequestHttpException('Required parameter "progress" is missing.');
        }
    }

    private function getVideo(string $oxoloVideoId, Context $context): OxoloVideoEntity
    {
        $criteria = (new Criteria())
            ->addFilter(new EqualsFilter('oxoloId', $oxoloVideoId));

        $video = $this->videoRepository->search($criteria, $context)->first();

        if (!$video) {
            throw new VideoNotFoundException($oxoloVideoId);
        }

        return $video;
    }
}
