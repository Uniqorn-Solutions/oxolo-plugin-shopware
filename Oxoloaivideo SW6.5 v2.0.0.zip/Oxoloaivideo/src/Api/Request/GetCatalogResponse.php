<?php declare(strict_types=1);

namespace Oxoloaivideo\Api\Request;

use JsonSerializable;

class GetCatalogResponse implements JsonSerializable
{
    public function __construct(private ?string $preview)
    {
    }

    public function getPreview(): ?string
    {
        return $this->preview;
    }

    public function setPreview(?string $preview): void
    {
        $this->preview = $preview;
    }


    public function jsonSerialize(): array
    {
        return [
            'preview' => $this->preview,
        ];
    }
}
