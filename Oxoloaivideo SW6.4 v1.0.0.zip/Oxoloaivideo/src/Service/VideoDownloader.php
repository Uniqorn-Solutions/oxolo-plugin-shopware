<?php declare(strict_types=1);

namespace Oxoloaivideo\Service;

use Exception;
use Oxoloaivideo\Api\Gateway;
use Oxoloaivideo\Entity\OxoloVideoCollection;
use Oxoloaivideo\Entity\OxoloVideoDefinition;
use Oxoloaivideo\Entity\OxoloVideoEntity;
use Oxoloaivideo\Service\Exception\VideoExistsException;
use Psr\Log\LoggerInterface;
use Shopware\Core\Content\Media\File\FileSaver;
use Shopware\Core\Content\Media\File\MediaFile;
use Shopware\Core\Content\Product\Exception\ProductNotFoundException;
use Shopware\Core\Content\Product\ProductEntity;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Uuid\Uuid;

class VideoDownloader
{
    private EntityRepositoryInterface $mediaRepository;
    private EntityRepositoryInterface $productMediaRepository;
    private EntityRepositoryInterface $mediaFolderRepository;
    private EntityRepositoryInterface $oxoloVideoRepository;
    private EntityRepositoryInterface $productRepository;
    private FileSaver $fileSaver;
    private Gateway $gateway;
    private LoggerInterface $logger;

    public function __construct(
        EntityRepositoryInterface $mediaRepository,
        EntityRepositoryInterface $productMediaRepository,
        EntityRepositoryInterface $mediaFolderRepository,
        EntityRepositoryInterface $oxoloVideoRepository,
        EntityRepositoryInterface $productRepository,
        FileSaver $fileSaver,
        Gateway $gateway,
        LoggerInterface $logger
    ) {
        $this->mediaRepository = $mediaRepository;
        $this->productMediaRepository = $productMediaRepository;
        $this->mediaFolderRepository = $mediaFolderRepository;
        $this->oxoloVideoRepository = $oxoloVideoRepository;
        $this->productRepository = $productRepository;
        $this->fileSaver = $fileSaver;
        $this->gateway = $gateway;
        $this->logger = $logger;
    }

    public function downloadProductVideos(string $productId, Context $context): array
    {
        $product = $this->getProduct($productId, $context);
        /** @var OxoloVideoCollection $videosInProgress */
        $videosInProgress = $product->getExtension('oxoloaivideoVideos');

        if (!$videosInProgress) {
            return [0, 0, 0];
        }

        $downloaded = 0;
        $failed = 0;

        foreach ($videosInProgress as $video) {
            try {
                $this->downloadVideo($video, $context);
                $downloaded++;
            } catch (Exception $exception) {
                $this->logger->error(
                    'Couldn\'t download video with Oxolo ID {oxoloVideoId} for product {productNumber}. ' . $exception,
                    [
                        'oxoloVideoId' => $video->getOxoloId(),
                        'productNumber' => $product->getProductNumber(),
                    ]
                );

                $failed++;
            }
        }

        return [
            $downloaded,
            $videosInProgress->count() - $downloaded,
            $failed
        ];
    }

    /**
     * @throws Exception
     * @throws VideoExistsException
     */
    public function downloadVideo(OxoloVideoEntity $video, Context $context): void
    {
        if ($this->videoExists($video->getOxoloId(), $context)) {
            throw new VideoExistsException($video->getOxoloId());
        }

        $response = $this->gateway->getVideo($video->getOxoloId());

        if ($response->getStatus() != OxoloVideoDefinition::STATUS_DONE) {
            throw new Exception('Video in progress.');
        }

        $mediaId = $this->downloadMedia(
            $video->getOxoloId(),
            $response->getLink(),
            $context
        );

        $this->logger->info(
            'Downloaded video with Oxolo ID {oxoloVideoId}.',
            ['oxoloVideoId' => $video->getOxoloId()],
        );

        $thumbnailMediaId = $this->downloadMedia(
            $video->getOxoloId(),
            $response->getThumbnail(),
            $context
        );

        $this->logger->info(
            'Downloaded thumbnail for video with Oxolo ID {oxoloVideoId}.',
            ['oxoloVideoId' => $video->getOxoloId()],
        );

        $this->createProductMedia($video->getProductId(), $mediaId, $context);
        $this->updateVideo($video->getId(), $mediaId, $thumbnailMediaId, $context);
    }

    /**
     * @throws Exception
     */
    private function downloadMedia(string $targetMediaName, string $sourceMediaUrl, Context $context): string
    {
        $tmpFilePath = tempnam(sys_get_temp_dir(), 'oxoloaivideo_');

        try {
            $this->fetchFileFromUrl($sourceMediaUrl, $tmpFilePath);
            $mediaId = $this->createMediaFromFile($tmpFilePath, $targetMediaName, $sourceMediaUrl, $context);
        } catch (Exception $exception) {
            throw $exception;
        } finally {
            unlink($tmpFilePath);
        }

        return $mediaId;
    }

    /**
     * @throws Exception
     */
    private function fetchFileFromUrl(string $fileUrl, string $targetFilePath): void
    {
        $filePointer = @fopen($fileUrl, 'r');

        if ($filePointer === false) {
            throw new Exception("Could not open file from the URL $fileUrl.");
        }

        $writeResult = file_put_contents($targetFilePath, $filePointer);

        if ($writeResult === false) {
            throw new Exception("Could not write to file $targetFilePath.");
        }
    }

    private function createMediaFromFile(
        string $tmpFilePath,
        string $targetMediaName,
        string $sourceMediaUrl,
        Context $context
    ): string {
        $mediaId = Uuid::randomHex();
        $sourceFileName = $this->getFileNameFromUrl($sourceMediaUrl);
        $fileExtension = pathinfo($sourceFileName, PATHINFO_EXTENSION);

        $createData = [[
            'id' => $mediaId,
            'mediaFolderId' => $this->getProductMediaFolderId($context),
        ]];

        $this->mediaRepository->create($createData, $context);

        $mediaFile = new MediaFile(
            $tmpFilePath,
            mime_content_type($tmpFilePath),
            $fileExtension,
            filesize($tmpFilePath)
        );

        $this->fileSaver->persistFileToMedia($mediaFile, $targetMediaName, $mediaId, $context);

        return $mediaId;
    }

    private function getFileNameFromUrl(string $url): string
    {
        return explode('?', basename($url))[0];
    }

    private function videoExists(string $oxoloVideoId, Context $context): bool
    {
        $criteria = (new Criteria())
            ->addFilter(new EqualsFilter('fileName', $oxoloVideoId));

        return (bool) $this->mediaRepository->searchIds($criteria, $context)->firstId();
    }

    private function createProductMedia(string $productId, string $mediaId, Context $context): void
    {
        $createData = [[
            'mediaId' => $mediaId,
            'productId' => $productId,
        ]];

        $this->productMediaRepository->create($createData, $context);
    }

    private function getProductMediaFolderId(Context $context): string
    {
        $criteria = (new Criteria())
            ->addFilter(new EqualsFilter('defaultFolder.entity', 'product'));

        return $this->mediaFolderRepository->searchIds($criteria, $context)->firstId();
    }

    private function getProduct(string $productId, Context $context): ProductEntity
    {
        $criteria = (new Criteria([$productId]))
            ->addAssociation('oxoloaivideoVideos');

        $criteria->getAssociation('oxoloaivideoVideos')
                 ->addFilter(new EqualsFilter('mediaId', null));

        $product = $this->productRepository->search($criteria, $context)->first();

        if (!$product) {
            throw new ProductNotFoundException($productId);
        }

        return $product;
    }

    private function updateVideo(
        string $oxoloVideoId,
        string $mediaId,
        string $thumbnailMediaId,
        Context $context
    ): void {
        $updateData = [[
            'id' => $oxoloVideoId,
            'mediaId' => $mediaId,
            'thumbnailMediaId' => $thumbnailMediaId,
        ]];

        $this->oxoloVideoRepository->update($updateData, $context);
    }
}
