<?php declare(strict_types=1);

namespace Oxoloaivideo\Api\Request;

use GuzzleHttp\Psr7\Utils;

class CreateMediaRequest
{
    private string $file;
    private string $mimeType;

    public function __construct(string $file, string $mimeType)
    {
        $this->file = $file;
        $this->mimeType = $mimeType;
    }

    public function getFile(): string
    {
        return $this->file;
    }

    public function setFile(string $file): void
    {
        $this->file = $file;
    }

    public function getMimeType(): string
    {
        return $this->mimeType;
    }

    public function setMimeType(string $mimeType): void
    {
        $this->mimeType = $mimeType;
    }

    public function toArray(): array
    {
        return [
            [
                'name' => 'asset',
                'contents' => Utils::tryFopen($this->file, 'r'),
            ],
            [
                'name' => 'media_type',
                'contents' => 'IMAGE',
            ],
        ];
    }
}
