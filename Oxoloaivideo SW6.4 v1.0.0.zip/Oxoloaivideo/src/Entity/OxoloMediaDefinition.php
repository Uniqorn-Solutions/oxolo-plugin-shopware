<?php declare(strict_types=1);

namespace Oxoloaivideo\Entity;

use Shopware\Core\Content\Media\MediaDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\EntityDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\Field\FkField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\PrimaryKey;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\Required;
use Shopware\Core\Framework\DataAbstractionLayer\Field\IdField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\OneToOneAssociationField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\StringField;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;

class OxoloMediaDefinition extends EntityDefinition
{
    public const ENTITY_NAME = 'oxoloaivideo_media';

    public function getEntityName(): string
    {
        return self::ENTITY_NAME;
    }

    public function getEntityClass(): string
    {
        return OxoloMediaEntity::class;
    }

    public function getCollectionClass(): string
    {
        return OxoloMediaCollection::class;
    }

    public function defineFields(): FieldCollection
    {
        return new FieldCollection([
            (new IdField('id', 'id'))->setFlags(new Required(), new PrimaryKey()),
            (new StringField('oxolo_id', 'oxoloId'))->addFlags(new Required()),
            new FkField('media_id', 'mediaId', MediaDefinition::class),

            new OneToOneAssociationField(
                'media',
                'media_id',
                'id',
                MediaDefinition::class,
                false
            ),
        ]);
    }
}
