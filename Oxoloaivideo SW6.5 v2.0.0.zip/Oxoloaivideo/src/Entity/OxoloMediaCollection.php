<?php declare(strict_types=1);

namespace Oxoloaivideo\Entity;

use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;

/**
 * @method void                  add(OxoloMediaEntity $entity)
 * @method void                  set(string $key, OxoloMediaEntity $entity)
 * @method OxoloMediaEntity[]    getIterator()
 * @method OxoloMediaEntity[]    getElements()
 * @method OxoloMediaEntity|null get(string $key)
 * @method OxoloMediaEntity|null first()
 * @method OxoloMediaEntity|null last()
 */
class OxoloMediaCollection extends EntityCollection
{
    protected function getExpectedClass(): string
    {
        return OxoloMediaEntity::class;
    }
}
