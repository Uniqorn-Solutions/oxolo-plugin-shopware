# 2.0.0
- Compatibility with Shopware 6.5.
