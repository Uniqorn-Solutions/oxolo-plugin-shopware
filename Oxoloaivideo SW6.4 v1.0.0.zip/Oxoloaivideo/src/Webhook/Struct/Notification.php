<?php declare(strict_types=1);

namespace Oxoloaivideo\Webhook\Struct;

use Shopware\Core\Framework\Struct\Struct;
use Symfony\Component\HttpFoundation\Request;

class Notification extends Struct
{
    private ?string $oxoloVideoId;
    private ?int $progress;
    private ?string $token;

    public static function fromRequest(Request $request): Notification
    {
        $data = json_decode($request->getContent(), true);

        $notification = new self();
        $notification->setOxoloVideoId($data['data']['videoId'] ?? null);
        $notification->setProgress($data['data']['progress'] ?? null);
        $notification->setToken($request->headers->get('token'));

        return $notification;
    }

    public function getOxoloVideoId(): ?string
    {
        return $this->oxoloVideoId;
    }

    public function setOxoloVideoId(?string $oxoloVideoId): void
    {
        $this->oxoloVideoId = $oxoloVideoId;
    }

    public function getProgress(): ?int
    {
        return $this->progress;
    }

    public function setProgress(?int $progress): void
    {
        $this->progress = $progress;
    }

    public function getToken(): ?string
    {
        return $this->token;
    }

    public function setToken(?string $token): void
    {
        $this->token = $token;
    }
}
