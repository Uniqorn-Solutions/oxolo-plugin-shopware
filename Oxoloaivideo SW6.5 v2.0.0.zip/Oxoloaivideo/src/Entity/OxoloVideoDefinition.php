<?php declare(strict_types=1);

namespace Oxoloaivideo\Entity;

use Shopware\Core\Content\Media\MediaDefinition;
use Shopware\Core\Content\Product\ProductDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\EntityDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\Field\FkField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\PrimaryKey;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\Required;
use Shopware\Core\Framework\DataAbstractionLayer\Field\IdField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\ManyToOneAssociationField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\OneToOneAssociationField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\ReferenceVersionField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\StringField;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;
use Shopware\Core\System\Language\LanguageDefinition;

class OxoloVideoDefinition extends EntityDefinition
{
    public const STATUS_DONE = 'done';
    public const STATUS_IN_PROGRESS = 'in_progress';

    public const ENTITY_NAME = 'oxoloaivideo_video';

    public function getEntityName(): string
    {
        return self::ENTITY_NAME;
    }

    public function getEntityClass(): string
    {
        return OxoloVideoEntity::class;
    }

    public function getCollectionClass(): string
    {
        return OxoloVideoCollection::class;
    }

    public function defineFields(): FieldCollection
    {
        return new FieldCollection([
            (new IdField('id', 'id'))->setFlags(new Required(), new PrimaryKey()),
            (new StringField('oxolo_id', 'oxoloId'))->addFlags(new Required()),
            new FkField('product_id', 'productId', ProductDefinition::class),
            new ReferenceVersionField(ProductDefinition::class),
            new FkField('media_id', 'mediaId', MediaDefinition::class),
            new FkField('thumbnail_media_id', 'thumbnailMediaId', MediaDefinition::class),
            new FkField('language_id', 'languageId', LanguageDefinition::class),

            new ManyToOneAssociationField(
                'product',
                'product_id',
                ProductDefinition::class,
                'id',
                false,
            ),
            new OneToOneAssociationField(
                'media',
                'media_id',
                'id',
                MediaDefinition::class,
                false,
            ),
            new OneToOneAssociationField(
                'thumbnailMedia',
                'thumbnail_media_id',
                'id',
                MediaDefinition::class,
                false,
            ),
            new ManyToOneAssociationField(
                'language',
                'language_id',
                LanguageDefinition::class,
                'id',
                false,
            ),
        ]);
    }
}
