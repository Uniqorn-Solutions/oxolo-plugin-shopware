<?php declare(strict_types=1);

namespace Oxoloaivideo\Service;

use Oxoloaivideo\Api\Gateway;
use Oxoloaivideo\Api\Exception\ApiException;
use Oxoloaivideo\Api\Request\CreateMediaRequest;
use Oxoloaivideo\Api\RequestFactory;
use Oxoloaivideo\Entity\OxoloVideoDefinition;
use Shopware\Core\Content\Media\MediaEntity;
use Shopware\Core\Content\Product\Exception\ProductNotFoundException;
use Shopware\Core\Content\Product\ProductEntity;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\System\SalesChannel\SalesChannelContext;

class VideoGenerator
{
    private EntityRepositoryInterface $productRepository;
    private EntityRepositoryInterface $oxoloMediaRepository;
    private EntityRepositoryInterface $oxoloVideoRepository;
    private RequestFactory $requestFactory;
    private Gateway $gateway;

    public function __construct(
        EntityRepositoryInterface $productRepository,
        EntityRepositoryInterface $oxoloMediaRepository,
        EntityRepositoryInterface $oxoloVideoRepository,
        RequestFactory $requestFactory,
        Gateway $gateway
    ) {
        $this->productRepository = $productRepository;
        $this->oxoloMediaRepository = $oxoloMediaRepository;
        $this->oxoloVideoRepository = $oxoloVideoRepository;
        $this->requestFactory = $requestFactory;
        $this->gateway = $gateway;
    }

    /**
     * @throws ApiException
     */
    public function createVideo(
        string $productId,
        ?string $actorId,
        ?string $musicId,
        string $templateId,
        ?string $voiceId,
        string $description,
        SalesChannelContext $salesChannelContext
    ): void {
        $product = $this->getProduct($productId, $salesChannelContext->getContext());

        $this->createOxoloMedia($product, $salesChannelContext->getContext());

        $request = $this->requestFactory->createVideoRequest(
            $productId,
            $actorId,
            $musicId,
            $templateId,
            $voiceId,
            $description,
            $salesChannelContext
        );
        $oxoloVideoId = $this->gateway->createVideo($request);

        $this->createOxoloVideo($oxoloVideoId, $product, $salesChannelContext);
    }

    private function getProduct(string $productId, Context $context): ProductEntity
    {
        $criteria = (new Criteria([$productId]))
            ->addAssociation('media.media.oxoloaivideoMedia');

        $product = $this->productRepository->search($criteria, $context)->first();

        if (!$product) {
            throw new ProductNotFoundException($productId);
        }

        return $product;
    }

    private function createOxoloVideo(
        string $oxoloVideoId,
        ProductEntity $product,
        SalesChannelContext $salesChannelContext
    ): void {
        $createData = [[
            'oxoloId' => $oxoloVideoId,
            'productId' => $product->getId(),
            'productVersionId' => $product->getVersionId(),
            'languageId' => $salesChannelContext->getLanguageId(),
            'status' => OxoloVideoDefinition::STATUS_IN_PROGRESS,
        ]];

        $this->oxoloVideoRepository->create($createData, $salesChannelContext->getContext());
    }

    /**
     * @throws ApiException
     */
    private function createOxoloMedia(ProductEntity $product, Context $context): void
    {
        /** @var MediaEntity $media */
        foreach ($product->getMedia()->getMedia() as $media) {
            if (
                str_contains($media->getMimeType(), 'image/')
                && !$media->hasExtension('oxoloaivideoMedia')
            ) {
                $request = new CreateMediaRequest($media->getUrl(), $media->getMimeType());
                $oxoloMediaId = $this->gateway->createMedia($request);

                $createData = [[
                    'oxoloId' => $oxoloMediaId,
                    'mediaId' => $media->getId(),
                ]];

                $this->oxoloMediaRepository->create($createData, $context);
            }
        }
    }
}
