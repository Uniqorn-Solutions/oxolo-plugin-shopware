<?php declare(strict_types=1);

namespace Oxoloaivideo\Administration\Controller;

use Exception;
use Oxoloaivideo\Administration\Exception\NotEnoughCreditsException;
use Oxoloaivideo\Api\Gateway;
use Oxoloaivideo\Api\Exception\ApiException;
use Oxoloaivideo\Entity\OxoloVideoCollection;
use Oxoloaivideo\Entity\OxoloVideoDefinition;
use Oxoloaivideo\Service\VideoDownloader;
use Oxoloaivideo\Service\VideoGenerator;
use Shopware\Core\Content\Product\Exception\ProductNotFoundException;
use Shopware\Core\Defaults;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Routing\Exception\MissingRequestParameterException;
use Shopware\Core\Framework\Util\Random;
use Shopware\Core\Framework\Validation\DataBag\RequestDataBag;
use Shopware\Core\PlatformRequest;
use Shopware\Core\System\SalesChannel\Context\SalesChannelContextServiceInterface;
use Shopware\Core\System\SalesChannel\Context\SalesChannelContextServiceParameters;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route(defaults={"_routeScope"={"api"}})
 */
class VideoController extends AbstractController
{
    private EntityRepositoryInterface $productRepository;
    private EntityRepositoryInterface $salesChannelRepository;
    private SalesChannelContextServiceInterface $salesChannelContextService;
    private EntityRepositoryInterface $oxoloVideoRepository;
    private VideoDownloader $videoDownloader;
    private VideoGenerator $videoGenerator;
    private Gateway $gateway;

    public function __construct(
        EntityRepositoryInterface $productRepository,
        EntityRepositoryInterface $salesChannelRepository,
        EntityRepositoryInterface $oxoloVideoRepository,
        SalesChannelContextServiceInterface $salesChannelContextService,
        VideoDownloader $videoDownloader,
        VideoGenerator $videoGenerator,
        Gateway $gateway
    ) {
        $this->productRepository = $productRepository;
        $this->salesChannelRepository = $salesChannelRepository;
        $this->salesChannelContextService = $salesChannelContextService;
        $this->oxoloVideoRepository = $oxoloVideoRepository;
        $this->videoDownloader = $videoDownloader;
        $this->videoGenerator = $videoGenerator;
        $this->gateway = $gateway;
    }

    /**
     * @Route(
     *     "/api/_action/oxoloaivideo/check-progress/{productId}",
     *     name="api.action.oxoloaivideo.check-progress",
     *     methods={"GET"}
     * )
     * @throws Exception
     */
    public function checkProgress(string $productId, Context $context): JsonResponse
    {
        if (!$productId) {
            throw new MissingRequestParameterException('productId');
        }

        $this->checkIfProductExists($productId, $context);

        [$toDownload, $inProgress] = $this->countVideosToDownloadAndInProgress($productId, $context);

        return new JsonResponse([
            'toDownload' => $toDownload,
            'inProgress' => $inProgress,
        ]);
    }

    /**
     * @Route(
     *     "/api/_action/oxoloaivideo/create-video",
     *     name="api.action.oxoloaivideo.create-video",
     *     methods={"POST"}
     * )
     * @throws ApiException
     * @throws ProductNotFoundException
     */
    public function createVideo(Request $request, RequestDataBag $dataBag, Context $context): JsonResponse
    {
        $actorId = $dataBag->get('actorId');
        $description = $dataBag->get('description');
        $musicId = $dataBag->get('musicId');
        $productId = $dataBag->get('productId');
        $templateId = $dataBag->get('templateId');
        $voiceId = $dataBag->get('voiceId');

        if (!$productId) {
            throw new MissingRequestParameterException('productId');
        }
        if (!$templateId) {
            throw new MissingRequestParameterException('templateId');
        }
        if (!$description) {
            throw new MissingRequestParameterException('description');
        }

        $this->checkIfProductExists($productId, $context);
        $this->checkIfEnoughCredits();

        $salesChannelContext = $this->getSalesChannelContext($request, $context);

        $this->videoGenerator->createVideo(
            $productId,
            $actorId,
            $musicId,
            $templateId,
            $voiceId,
            $description,
            $salesChannelContext
        );

        return new JsonResponse(null, Response::HTTP_NO_CONTENT);
    }

    /**
     * @Route(
     *     "/api/_action/oxoloaivideo/download-videos/{productId}",
     *     name="api.action.oxoloaivideo.download-videos",
     *     methods={"GET"}
     * )
     * @throws Exception
     */
    public function downloadVideos(string $productId, Context $context): JsonResponse
    {
        if (!$productId) {
            throw new MissingRequestParameterException('productId');
        }

        $this->checkIfProductExists($productId, $context);

        [$downloaded, $inProgress, $failed] = $this->videoDownloader->downloadProductVideos($productId, $context);

        return new JsonResponse([
            'downloaded' => $downloaded,
            'inProgress' => $inProgress,
            'failed' => $failed,
        ]);
    }

    /**
     * @throws ApiException
     */
    private function checkIfEnoughCredits(): void
    {
        $credits = $this->gateway->getCredits();

        if ($credits < 5) {
            throw new NotEnoughCreditsException($credits);
        }
    }

    /**
     * @throws ProductNotFoundException
     */
    private function checkIfProductExists(string $productId, Context $context): void
    {
        $criteria = new Criteria([$productId]);

        $product = $this->productRepository->searchIds($criteria, $context)->firstId();

        if (!$product) {
            throw new ProductNotFoundException($productId);
        }
    }

    /**
     * Creates sales channel context based on the language selected in administration.
     */
    private function getSalesChannelContext(Request $request, Context $context): SalesChannelContext
    {
        $criteria = (new Criteria())
            ->addFilter(new EqualsFilter('typeId', Defaults::SALES_CHANNEL_TYPE_STOREFRONT));

        $salesChannelId = $this->salesChannelRepository->searchIds(
            $criteria,
            Context::createDefaultContext()
        )->firstId();

        return $this->salesChannelContextService->get(
            new SalesChannelContextServiceParameters(
                $salesChannelId,
                Random::getAlphanumericString(32),
                $request->headers->get(PlatformRequest::HEADER_LANGUAGE_ID),
                $context->getCurrencyId()
            )
        );
    }

    /**
     * @return int[]
     * @throws ApiException
     */
    private function countVideosToDownloadAndInProgress(string $productId, Context $context): array
    {
        $toDownload = 0;
        $inProgress = 0;

        $criteria = (new Criteria())
            ->addFilter(
                new EqualsFilter('productId', $productId),
                new EqualsFilter('mediaId', null)
            );

        /** @var OxoloVideoCollection $oxoloVideos */
        $oxoloVideos = $this->oxoloVideoRepository->search($criteria, $context)->getEntities();

        foreach ($oxoloVideos as $oxoloVideo) {
            $response = $this->gateway->getVideo($oxoloVideo->getOxoloId());

            if ($response->getStatus() == OxoloVideoDefinition::STATUS_DONE) {
                $toDownload++;
            } elseif ($response->getStatus() == OxoloVideoDefinition::STATUS_IN_PROGRESS) {
                $inProgress++;
            }
        }

        return [$toDownload, $inProgress];
    }
}
