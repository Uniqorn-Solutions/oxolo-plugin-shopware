import './oxoloaivideo-catalog-preview.scss';
import template from './oxoloaivideo-catalog-preview.html.twig';

Shopware.Component.register('oxoloaivideo-catalog-preview', {
    template,

    inject: [
        'oxoloaivideoCatalogService',
    ],

    props: {
        catalogId: {
            type: String,
            required: true,
        },
        catalogType: {
            type: String,
            required: true,
        },
        mediaType: {
            type: String,
            required: true,
        },
    },

    data() {
        return {
            isLoading: true,
            preview: null,
        };
    },

    watch: {
        catalogId() {
            this.loadCatalog();
        },
    },

    mounted() {
        this.loadCatalog();
    },

    methods: {
        async loadCatalog() {
            await this.oxoloaivideoCatalogService.getCatalog(this.catalogId)
                .then((response) => {
                    if (this.catalogType === 'actor') {
                        this.preview = response.catalog.preview + '-400x0';
                    } else if (this.catalogType === 'voice') {
                        this.preview = 'https://media.oxolo.com/voices/' + this.catalogId + '.mp3';
                    } else {
                        this.preview = response.catalog.preview;
                    }

                    this.isLoading = false;
                })
                .catch(() => {
                    this.preview = null;
                    this.isLoading = false;
                });
        },
    },
});
