<?php declare(strict_types=1);

namespace Oxoloaivideo\Storefront\Struct;

use Shopware\Core\Framework\Struct\Struct;

class MediaExtension extends Struct
{
    private bool $isOxoloVideo = true;

    public function isOxoloVideo(): bool
    {
        return $this->isOxoloVideo;
    }
}
