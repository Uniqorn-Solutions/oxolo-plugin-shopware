<?php declare(strict_types=1);

namespace Oxoloaivideo\Api\Request;

class CreateWebhookRequest
{
    private string $url;
    private string $token;

    public function __construct(string $url, string $token)
    {
        $this->url = $url;
        $this->token = $token;
    }

    public function toArray(): array
    {
        return [
            'webhook_url' => $this->url,
            'webhook_url_method' => 'post',
            'token' => $this->token,
            'meta' => [],
        ];
    }
}
