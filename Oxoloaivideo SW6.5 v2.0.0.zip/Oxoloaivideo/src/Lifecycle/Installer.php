<?php declare(strict_types=1);

namespace Oxoloaivideo\Lifecycle;

use Shopware\Core\System\SystemConfig\SystemConfigService;

class Installer
{
    public function __construct(private readonly SystemConfigService $systemConfigService)
    {
    }

    public function install(): void
    {
        $this->createWebhookToken();
    }

    private function createWebhookToken(): void
    {
        $token = $this->systemConfigService->get('Oxoloaivideo.config.webhookToken');

        if (!$token) {
            $token = bin2hex(random_bytes(64));
            $this->systemConfigService->set('Oxoloaivideo.config.webhookToken', $token);
        }
    }
}
