<?php declare(strict_types=1);

namespace Oxoloaivideo\Storefront\Subscriber;

use Oxoloaivideo\Entity\OxoloVideoEntity;
use Shopware\Core\Content\Product\Aggregate\ProductMedia\ProductMediaEntity;
use Shopware\Storefront\Page\Product\ProductPageCriteriaEvent;
use Shopware\Storefront\Page\Product\ProductPageLoadedEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class StorefrontSubscriber implements EventSubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return [
            ProductPageCriteriaEvent::class => 'addOxoloVideoAssociation',
            ProductPageLoadedEvent::class => 'filterOxoloVideosByLanguage',
        ];
    }

    public function addOxoloVideoAssociation(ProductPageCriteriaEvent $event): void
    {
        $event->getCriteria()->addAssociation('media.media.oxoloaivideoVideo.thumbnailMedia.thumbnails');
    }

    public function filterOxoloVideosByLanguage(ProductPageLoadedEvent $event): void
    {
        $productMedia = $event->getPage()->getProduct()->getMedia();

        /** @var ProductMediaEntity $productMediaEntity */
        foreach ($productMedia as $productMediaEntity) {
            /** @var OxoloVideoEntity $oxoloVideo */
            $oxoloVideo = $productMediaEntity->getMedia()->getExtension('oxoloaivideoVideo');

            if ($oxoloVideo && $oxoloVideo->getLanguageId() != $event->getContext()->getLanguageId()) {
                $productMedia->remove($productMediaEntity->getId());
            }
        }
    }
}
