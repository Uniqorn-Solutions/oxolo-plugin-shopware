<?php declare(strict_types=1);

namespace Oxoloaivideo\Webhook\MesssageQueue;

class DownloadOxoloVideo
{
    private string $videoId;
    private string $oxoloVideoId;

    public function __construct(string $videoId, string $oxoloVideoId)
    {
        $this->videoId = $videoId;
        $this->oxoloVideoId = $oxoloVideoId;
    }

    public function getVideoId(): string
    {
        return $this->videoId;
    }

    public function getOxoloVideoId(): string
    {
        return $this->oxoloVideoId;
    }
}
