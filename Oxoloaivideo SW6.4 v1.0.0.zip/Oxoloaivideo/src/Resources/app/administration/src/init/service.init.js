import OxoloaivideoCatalogService from '../core/service/api/oxoloaivideo-catalog.api.service'
import OxoloaivideoVideoService from '../core/service/api/oxoloaivideo-video.api.service'

Shopware.Service().register('oxoloaivideoCatalogService', (container) => {
    return new OxoloaivideoCatalogService(
        Shopware.Application.getContainer('init').httpClient,
        Shopware.Service('loginService'),
    );
});
Shopware.Service().register('oxoloaivideoVideoService', (container) => {
    return new OxoloaivideoVideoService(
        Shopware.Application.getContainer('init').httpClient,
        Shopware.Service('loginService'),
    );
});
