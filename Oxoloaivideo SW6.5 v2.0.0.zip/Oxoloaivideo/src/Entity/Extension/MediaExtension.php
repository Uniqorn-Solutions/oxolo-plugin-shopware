<?php declare(strict_types=1);

namespace Oxoloaivideo\Entity\Extension;

use Oxoloaivideo\Entity\OxoloMediaDefinition;
use Oxoloaivideo\Entity\OxoloVideoDefinition;
use Shopware\Core\Content\Media\MediaDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\EntityExtension;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\SetNullOnDelete;
use Shopware\Core\Framework\DataAbstractionLayer\Field\OneToOneAssociationField;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;

class MediaExtension extends EntityExtension
{
    public function extendFields(FieldCollection $collection): void
    {
        $collection->add(
            (new OneToOneAssociationField(
                'oxoloaivideoMedia',
                'id',
                'media_id',
                OxoloMediaDefinition::class,
                false
            ))->addFlags(new SetNullOnDelete())
        );
        $collection->add(
            (new OneToOneAssociationField(
                'oxoloaivideoVideo',
                'id',
                'media_id',
                OxoloVideoDefinition::class,
                false
            ))->addFlags(new SetNullOnDelete())
        );
    }

    public function getDefinitionClass(): string
    {
        return MediaDefinition::class;
    }
}
