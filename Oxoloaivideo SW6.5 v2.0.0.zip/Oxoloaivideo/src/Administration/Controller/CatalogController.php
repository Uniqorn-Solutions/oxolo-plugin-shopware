<?php declare(strict_types=1);

namespace Oxoloaivideo\Administration\Controller;

use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Exception;
use Oxoloaivideo\Api\Gateway;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Routing\Exception\MissingRequestParameterException;
use Shopware\Core\System\Locale\LocaleEntity;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

#[Route(defaults: ['_routeScope' => ['api']])]
class CatalogController extends AbstractController
{
    public function __construct(
        private readonly Gateway $gateway,
        private readonly EntityRepository $localeRepository,
    ) {
    }

    /**
     * @throws Exception
     */
    #[Route(
        path: '/api/_action/oxoloaivideo/catalogs/{filter}',
        name: 'api.action.oxoloaivideo.catalogs',
        methods: ['GET']
    )]
    public function getCatalogs(Request $request, string $filter, Context $context): JsonResponse
    {
        if (!$filter) {
            throw new MissingRequestParameterException('filter');
        }

        $catalogs = $this->gateway->getCatalogs($filter);

        if ($filter == 'voice') {
            $catalogs = $this->filterCatalogsByLanguage($catalogs, $request, $context);
        }

        usort($catalogs, fn($a, $b) => $a['name'] <=> $b['name']);

        return new JsonResponse(['catalogs' => $catalogs]);
    }

    /**
     * @throws Exception
     */
    #[Route(
        path: '/api/_action/oxoloaivideo/catalog/{catalogId}',
        name: 'api.action.oxoloaivideo.catalog',
        methods: ['GET']
    )]
    public function getCatalog(string $catalogId): JsonResponse
    {
        if (!$catalogId) {
            throw new MissingRequestParameterException('catalogId');
        }

        $catalog = $this->gateway->getCatalog($catalogId);

        return new JsonResponse(['catalog' => $catalog]);
    }

    private function filterCatalogsByLanguage(array $catalog, Request $request, Context $context): array
    {
//        $filteredCatalog = [];
//        $languageId = $request->headers->get(PlatformRequest::HEADER_LANGUAGE_ID);
//        $localeCode = $this->getLanguageLocaleCode($languageId, $context);
//        $localeCode = $localeCode != 'en-GB' ?: 'en-US';
        // temporary allowing only English, as Oxolo doesn't support other languages yet
        $localeCode = 'en-US';

        foreach ($catalog as $id => $item) {
            if ($item['language'] == $localeCode) {
                $filteredCatalog[] = $item;
            }
        }

        return $filteredCatalog;
    }

    private function getLanguageLocaleCode(?string $languageId, Context $context): string
    {
        $criteria = (new Criteria())
            ->addFilter(new EqualsFilter('languages.id', $languageId));

        /** @var LocaleEntity $locale */
        $locale = $this->localeRepository->search($criteria, $context)->first();

        return $locale->getCode();
    }
}
