<?php declare(strict_types=1);

namespace Oxoloaivideo\Migration;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Exception;
use Shopware\Core\Framework\Migration\MigrationStep;

class Migration1683887008CreateThumbnailColumn extends MigrationStep
{
    public function getCreationTimestamp(): int
    {
        return 1683887008;
    }

    /**
     * @throws Exception
     */
    public function update(Connection $connection): void
    {
        $connection->executeStatement('
            ALTER TABLE `oxoloaivideo_video`
            ADD COLUMN `thumbnail_media_id` BINARY(16) NULL AFTER `media_id`,
            ADD CONSTRAINT `fk.oxoloaivideo_video.thumbnail_media_id`
                FOREIGN KEY (`thumbnail_media_id`)
                REFERENCES `media` (`id`)
                ON DELETE SET NULL
                ON UPDATE CASCADE
        ');
    }

    public function updateDestructive(Connection $connection): void
    {
    }
}
