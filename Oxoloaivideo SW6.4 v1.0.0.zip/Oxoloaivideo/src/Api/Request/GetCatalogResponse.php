<?php declare(strict_types=1);

namespace Oxoloaivideo\Api\Request;

use JsonSerializable;

class GetCatalogResponse implements JsonSerializable
{
    private ?string $preview = null;

    public function __construct(?string $preview)
    {
        $this->preview = $preview;
    }

    public function getPreview(): ?string
    {
        return $this->preview;
    }

    public function setPreview(?string $preview): void
    {
        $this->preview = $preview;
    }


    public function jsonSerialize()
    {
        return [
            'preview' => $this->preview,
        ];
    }
}
