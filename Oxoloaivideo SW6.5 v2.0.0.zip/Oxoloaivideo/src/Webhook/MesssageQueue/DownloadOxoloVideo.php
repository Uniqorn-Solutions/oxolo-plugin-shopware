<?php declare(strict_types=1);

namespace Oxoloaivideo\Webhook\MesssageQueue;

use Shopware\Core\Framework\MessageQueue\AsyncMessageInterface;

class DownloadOxoloVideo implements AsyncMessageInterface
{
    public function __construct(
        private readonly string $videoId,
        private readonly string $oxoloVideoId,
    ) {
    }

    public function getVideoId(): string
    {
        return $this->videoId;
    }

    public function getOxoloVideoId(): string
    {
        return $this->oxoloVideoId;
    }
}
