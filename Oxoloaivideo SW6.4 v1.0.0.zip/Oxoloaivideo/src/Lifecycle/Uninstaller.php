<?php declare(strict_types=1);

namespace Oxoloaivideo\Lifecycle;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Exception;

class Uninstaller
{
    private Connection $connection;

    public function __construct(Connection $connection)
    {
        $this->connection = $connection;
    }

    /**
     * @throws Exception
     */
    public function uninstall(): void
    {
        $this->connection->executeStatement('DROP TABLE IF EXISTS `oxoloaivideo_video`');
        $this->connection->executeStatement('DROP TABLE IF EXISTS `oxoloaivideo_media`');
    }
}
