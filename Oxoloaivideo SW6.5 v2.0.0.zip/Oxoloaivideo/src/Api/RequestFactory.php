<?php declare(strict_types=1);

namespace Oxoloaivideo\Api;

use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Oxoloaivideo\Api\Request\CreateVideoRequest;
use Oxoloaivideo\Api\Request\CreateWebhookRequest;
use Oxoloaivideo\Entity\OxoloMediaEntity;
use Shopware\Core\Content\Category\Service\CategoryBreadcrumbBuilder;
use Shopware\Core\Content\Media\MediaEntity;
use Shopware\Core\Content\Product\ProductEntity;
use Shopware\Core\Content\Seo\SeoUrlPlaceholderHandlerInterface;
use Shopware\Core\Defaults;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\System\SalesChannel\Aggregate\SalesChannelDomain\SalesChannelDomainEntity;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Core\System\SystemConfig\SystemConfigService;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Routing\RouterInterface;

class RequestFactory
{
    public function __construct(
        private readonly CategoryBreadcrumbBuilder $categoryBreadcrumbBuilder,
        private readonly SeoUrlPlaceholderHandlerInterface $seoUrlPlaceholderHandler,
        private readonly EntityRepository $productRepository,
        private readonly RouterInterface $router,
        private readonly SystemConfigService $systemConfigService,
    ) {
    }

    public function createWebhookRequest(): CreateWebhookRequest
    {
        $this->router->getContext()->setScheme('https');
        $webhookUrl = $this->router->generate(
            'api.action.oxoloaivideo.webhook',
            [],
            UrlGeneratorInterface::ABSOLUTE_URL,
        );
        $token = $this->systemConfigService->get('Oxoloaivideo.config.webhookToken');

        return new CreateWebhookRequest($webhookUrl, $token);
    }

    public function createVideoRequest(
        string $productId,
        ?string $actorId,
        ?string $musicId,
        string $templateId,
        ?string $voiceId,
        string $description,
        SalesChannelContext $salesChannelContext
    ): CreateVideoRequest {
        $product = $this->getProduct($productId, $salesChannelContext);
        $category = $this->categoryBreadcrumbBuilder->getProductSeoCategory($product, $salesChannelContext);

        $request = new CreateVideoRequest();
        $request->setActorId($actorId);
        $request->setLongDescription(strip_tags($description));
        $request->setMedia($this->getOxoloMedia($product));
        $request->setMusicId($musicId);
        $request->setShopUrl($this->getProductUrl($product, $salesChannelContext));
        $request->setShortDescription($this->getShortDescription($description));
        $request->setTemplateId($templateId);
        $request->setTitle($product->getTranslation('name'));
        $request->setVoiceId($voiceId);

        if ($category) {
            $request->setProductCategory($category->getName());
        }

        return $request;
    }

    private function getProduct(string $productId, SalesChannelContext $salesChannelContext): ProductEntity
    {
        $context = clone $salesChannelContext->getContext();
        $context->setConsiderInheritance(true);

        $criteria = (new Criteria([$productId]))
            ->addAssociation('media.media.oxoloaivideoMedia');

        return $this->productRepository->search($criteria, $context)->first();
    }

    /**
     * @return string[]
     */
    private function getOxoloMedia(ProductEntity $product): array
    {
        $oxoloMediaIds = [];

        /** @var MediaEntity $media */
        foreach ($product->getMedia()->getMedia() as $media) {
            if ($media->hasExtension('oxoloaivideoMedia')) {
                /** @var OxoloMediaEntity $oxoloMedia */
                $oxoloMedia = $media->getExtension('oxoloaivideoMedia');
                $oxoloMediaIds[] = $oxoloMedia->getOxoloId();
            }
        }

        return $oxoloMediaIds;
    }

    private function getProductUrl(ProductEntity $product, SalesChannelContext $salesChannelContext): string
    {
        $salesChannelDomain = $this->getDomainByLanguage($salesChannelContext->getLanguageId(), $salesChannelContext)
            ?? $this->getDomainByLanguage(Defaults::LANGUAGE_SYSTEM, $salesChannelContext);
        $salesChannelUrl = $salesChannelDomain->getUrl();
        $productUrl = $this->seoUrlPlaceholderHandler->generate(
            'frontend.detail.page',
            ['productId' => $product->getId()]
        );

        return $this->seoUrlPlaceholderHandler->replace($productUrl, $salesChannelUrl, $salesChannelContext);
    }

    private function getDomainByLanguage(
        string $languageId,
        SalesChannelContext $salesChannelContext
    ): ?SalesChannelDomainEntity {
        return $salesChannelContext->getSalesChannel()->getDomains()->filter(
            fn (SalesChannelDomainEntity $domain) => $domain->getLanguageId() == $languageId
        )->first();
    }

    private function getShortDescription(string $description): string
    {
        return strlen($description) > 100
            ? substr($description, 0, 97) . '...'
            : $description;
    }
}
