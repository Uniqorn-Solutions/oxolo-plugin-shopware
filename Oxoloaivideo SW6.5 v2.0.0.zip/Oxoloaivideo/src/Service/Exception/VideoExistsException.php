<?php declare(strict_types=1);

namespace Oxoloaivideo\Service\Exception;

use Shopware\Core\Framework\ShopwareHttpException;
use Symfony\Component\HttpFoundation\Response;

class VideoExistsException extends ShopwareHttpException
{
    public function __construct(private readonly string $oxoloVideoId)
    {
        parent::__construct(
            'Video with Oxolo ID {{ oxoloVideoId }} exists.',
            ['oxoloVideoId' => $this->oxoloVideoId]
        );
    }

    public function getOxoloVideoId(): string
    {
        return $this->oxoloVideoId;
    }

    public function getErrorCode(): string
    {
        return 'OXOLOAIVIDEO__VIDEO_EXISTS';
    }

    public function getStatusCode(): int
    {
        return Response::HTTP_BAD_REQUEST;
    }
}
