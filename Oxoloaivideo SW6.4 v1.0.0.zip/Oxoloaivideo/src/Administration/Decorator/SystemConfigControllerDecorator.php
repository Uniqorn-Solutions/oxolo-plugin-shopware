<?php declare(strict_types=1);

namespace Oxoloaivideo\Administration\Decorator;

use Oxoloaivideo\Api\Exception\ApiException;
use Oxoloaivideo\Webhook\Service\WebhookService;
use Shopware\Core\System\SystemConfig\Api\SystemConfigController;
use Shopware\Core\System\SystemConfig\Service\ConfigurationService;
use Shopware\Core\System\SystemConfig\SystemConfigService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route(defaults={"_routeScope"={"api"}})
 */
class SystemConfigControllerDecorator extends SystemConfigController
{
    private SystemConfigController $decorated;
    private WebhookService $webhookService;

    public function __construct(
        SystemConfigController $decorated,
        ConfigurationService $configurationService,
        SystemConfigService $systemConfig,
        WebhookService $webhookService
    ) {
        parent::__construct($configurationService, $systemConfig);

        $this->decorated = $decorated;
        $this->webhookService = $webhookService;
    }

    /**
     * @throws ApiException
     */
    public function batchSaveConfiguration(Request $request): JsonResponse
    {
        $response = $this->decorated->batchSaveConfiguration($request);

        $allParams = $request->request->all();

        if (str_starts_with(array_key_first(reset($allParams)), 'Oxoloaivideo')) {
            $this->webhookService->createWebhook();
        }

        return $response;
    }
}
