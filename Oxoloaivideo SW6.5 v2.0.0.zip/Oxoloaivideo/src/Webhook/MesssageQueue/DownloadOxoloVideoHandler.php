<?php declare(strict_types=1);

namespace Oxoloaivideo\Webhook\MesssageQueue;

use Exception;
use Oxoloaivideo\Entity\OxoloVideoEntity;
use Oxoloaivideo\Service\Exception\VideoExistsException;
use Oxoloaivideo\Service\Logger;
use Oxoloaivideo\Service\VideoDownloader;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Symfony\Component\Messenger\Attribute\AsMessageHandler;

#[AsMessageHandler]
class DownloadOxoloVideoHandler
{
    public function __construct(
        private readonly VideoDownloader $videoDownloader,
        private readonly EntityRepository $videoRepository,
        private readonly Logger $logger,
    ) {
    }

    /**
     * @throws Exception
     */
    public function __invoke(DownloadOxoloVideo $message): void
    {
        $context = Context::createDefaultContext();
        $video = $this->getVideo($message->getVideoId(), $context);

        if (!$video) {
            $this->logger->error(
                'Couldn\'t download video. Video with ID {videoId} not found.',
                [
                    'videoId'=> $message->getVideoId(),
                    'oxoloVideoId' => $message->getOxoloVideoId(),
                ],
            );

            return;
        }

        try {
            $this->videoDownloader->downloadVideo($video, $context);
        } catch (VideoExistsException) {
            return;
        } catch (Exception $exception) {
            $this->logger->error(
                'Download process for video with Oxolo ID {oxoloVideoId} failed. ' . $exception,
                ['oxoloVideoId' => $video->getOxoloId()],
            );

            throw $exception;
        }
    }

    public static function getHandledMessages(): iterable
    {
        return [DownloadOxoloVideo::class];
    }

    private function getVideo(string $videoId, Context $context): ?OxoloVideoEntity
    {
        $criteria = new Criteria([$videoId]);

        return $this->videoRepository->search($criteria, $context)->first();
    }
}
