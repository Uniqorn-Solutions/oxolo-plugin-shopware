<?php declare(strict_types=1);

namespace Oxoloaivideo\Api;

use GuzzleHttp\Client;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Exception\TransferException;
use GuzzleHttp\RequestOptions;
use Oxoloaivideo\Api\Exception\ApiException;
use Oxoloaivideo\Api\Request\CreateMediaRequest;
use Oxoloaivideo\Api\Request\CreateVideoRequest;
use Oxoloaivideo\Api\Request\CreateWebhookRequest;
use Oxoloaivideo\Api\Request\GetCatalogResponse;
use Oxoloaivideo\Api\Request\GetVideoResponse;
use Psr\Log\LoggerInterface;
use Shopware\Core\System\SystemConfig\SystemConfigService;

class Gateway
{
    private ?ClientInterface $client = null;

    private LoggerInterface $logger;
    private SystemConfigService $systemConfigService;

    public function __construct(
        LoggerInterface $logger,
        SystemConfigService $systemConfigService
    ) {
        $this->logger = $logger;
        $this->systemConfigService = $systemConfigService;
    }

    /**
     * @throws ApiException
     */
    public function getCredits(): int
    {
        $response = $this->request('get credits', 'get', ApiUrl::GET_CREDITS, [], false);

        return (int) $response['data']['results'];
    }

    /**
     * @return array<string, string>
     * @throws ApiException
     */
    public function getCatalogs(string $filter): array
    {
        $options = [RequestOptions::QUERY => ['filter' => strtoupper($filter)]];
        $response = $this->request('get catalogs', 'get', ApiUrl::GET_CATALOGS, $options, false);

        $catalog = [];
        $results = $response['data'];

        foreach ($results as $key => $result) {
            switch ($filter) {
                case 'actor':
                    if (!empty($result['actor_name'])) {
                        $catalog[] = [
                            'id' => $key,
                            'name' => $result['actor_name'],
                            'description' => $result['variation_name'],
                        ];
                    }
                    break;
                case 'music':
                case 'template':
                    if (!empty($result['name'])) {
                        $catalog[] = [
                            'id' => $key,
                            'name' => $result['name'],
                        ];
                    }
                    break;
                case 'voice':
                    if (!empty($result['display_id'])) {
                        $catalog[] = [
                            'id' => $key,
                            'name' => $result['display_id'],
                            'description' => $result['display_style'],
                            'language' => $result['language_code'],
                        ];
                    }
                    break;
            }
        }

        return $catalog;
    }

    /**
     * @throws ApiException
     */
    public function getCatalog(string $catalogId): GetCatalogResponse
    {
        $url = $this->buildUrl(ApiUrl::GET_CATALOG, ['catalogId' => $catalogId]);
        $response = $this->request('get catalog', 'get', $url, [], false);

        return new GetCatalogResponse($response['data'][$catalogId]['preview'] ?? null);
    }

    /**
     * @throws ApiException
     */
    public function createMedia(CreateMediaRequest $request): string
    {
        $options = [RequestOptions::MULTIPART => $request->toArray()];
        $response = $this->request('create media', 'post', ApiUrl::CREATE_MEDIA, $options);

        return $response['data']['results'];
    }

    /**
     * @throws ApiException
     */
    public function createVideo(CreateVideoRequest $request): string
    {
        $options = [RequestOptions::JSON => $request->toArray()];
        $response = $this->request('create video', 'post', ApiUrl::CREATE_VIDEO, $options);

        return $response['data']['identifier'];
    }

    /**
     * @throws ApiException
     */
    public function getVideo(string $videoId): GetVideoResponse
    {
        $url = $this->buildUrl(ApiUrl::GET_VIDEO, ['videoId' => $videoId]);
        $response = $this->request('get video', 'get', $url);

        return new GetVideoResponse(
            $response['data']['un_wateremark_link'],
            $response['data']['thumbnail'],
            $response['data']['status'],
        );
    }

    /**
     * @throws ApiException
     */
    public function registerUser(): void
    {
        $this->request('register user', 'post', ApiUrl::REGISTER_USER);
    }

    /**
     * @throws ApiException
     */
    public function createWebhook(CreateWebhookRequest $request): void
    {
        $options = [RequestOptions::JSON => $request->toArray()];
        $this->request('create webhook', 'post', ApiUrl::CREATE_WEBHOOK, $options);
    }

    /**
     * @throws ApiException
     */
    private function request(
        string $name,
        string $method,
        string $uri,
        array $options = [],
        bool $logging = true
    ) {
        $apiKey = $this->systemConfigService->get('Oxoloaivideo.config.apiKey');
        $authHeader = $this->isLiveMode()
            ? 'SHA256 Credential=142b22553d20b7d7d137e58309ba370f9322ee613d178f7cb8b8c63abb7d6cdc'
            : getenv('OXOLO_TEST_ENV_AUTH');

        $options[RequestOptions::HEADERS] = [
            'accept' => 'application/json',
            'Authorization' => $authHeader,
            'Oxolo-Key' => $apiKey,
        ];

        if ($logging) {
            $optionsWithoutCredentials = $this->anonymizeOptionsForLogging($options);

            $this->logger->debug(
                'API request: ' . $name,
                [
                    'method' => $method,
                    'uri' => $this->getClient()->getConfig('base_uri') . $uri,
                ] + $optionsWithoutCredentials,
            );
        }

        try {
            $response = $this->getClient()->request($method, $uri, $options);
        } catch (TransferException | GuzzleException $exception) {
            if ($exception instanceof RequestException) {
                $exceptionMessage = $exception->hasResponse() ? ((string) $exception->getResponse()->getBody()) : '';
            } else {
                $exceptionMessage = $exception->getMessage();
            }

            $this->logger->error(
                'API error: ' . $name,
                [
                    'code' => $exception->getCode(),
                    'content' => json_decode($exceptionMessage) ?? $exceptionMessage,
                ]
            );

            throw new ApiException($exceptionMessage);
        }

        if ($logging) {
            $this->logger->debug(
                'API response: ' . $name,
                [
                    'code' => $response->getStatusCode(),
                    'content' => json_decode((string) $response->getBody(), true) ?? (string) $response->getBody(),
                ]
            );
        }

        $data = json_decode((string) $response->getBody(), true);

        if ($data === null) {
            $this->logger->debug(
                'API error: couldn\'t parse the response.',
                ['response' => (string) $response->getBody()]
            );

            throw new ApiException('Couldn\'t parse the response.');
        }

        return $data;
    }

    private function buildUrl(string $template, array $values): string
    {
        $url = $template;

        foreach ($values as $variable => $value) {
            $url = str_replace('{' . $variable . '}', $value, $url);
        }

        return $url;
    }

    private function getClient(): ClientInterface
    {
        if (!$this->client) {
            $baseUri = $this->isLiveMode() ? ApiUrl::BASE_URL_LIVE : ApiUrl::BASE_URL_TEST;

            $this->client = new Client([
                'base_uri' => $baseUri,
            ]);
        }

        return $this->client;
    }

    private function isLiveMode(): bool
    {
        return !((bool) getenv('OXOLO_TEST_ENV_ENABLED'));
    }

    private function anonymizeOptionsForLogging(array $options): array
    {
        $authHeader = $options[RequestOptions::HEADERS]['Authorization'];
        $apiKey = $options[RequestOptions::HEADERS]['Oxolo-Key'];
        $token = $options[RequestOptions::JSON]['token'] ?? null;

        $options[RequestOptions::HEADERS]['Authorization'] = $this->anonymize($authHeader);
        $options[RequestOptions::HEADERS]['Oxolo-Key'] = $this->anonymize($apiKey);

        if ($token) {
            $options[RequestOptions::JSON]['token'] = $this->anonymize($token);
        }

        return $options;
    }

    private function anonymize(string $text): string
    {
        return '***' . substr($text, -3);
    }
}
