<?php declare(strict_types=1);

namespace Oxoloaivideo\Entity;

use Shopware\Core\Content\Media\MediaEntity;
use Shopware\Core\Content\Product\ProductEntity;
use Shopware\Core\Framework\DataAbstractionLayer\Entity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityIdTrait;

class OxoloVideoEntity extends Entity
{
    use EntityIdTrait;

    protected string $oxoloId;
    protected ?string $productId = null;
    protected ?string $mediaId = null;
    protected ?string $thumbnailMediaId = null;
    protected ?string $languageId = null;

    protected ?ProductEntity $product = null;
    protected ?MediaEntity $media = null;
    protected ?MediaEntity $thumbnailMedia = null;
    protected ?MediaEntity $language = null;

    public function getOxoloId(): string
    {
        return $this->oxoloId;
    }

    public function setOxoloId(string $oxoloId): void
    {
        $this->oxoloId = $oxoloId;
    }

    public function getProductId(): ?string
    {
        return $this->productId;
    }

    public function setProductId(?string $productId): void
    {
        $this->productId = $productId;
    }

    public function getMediaId(): ?string
    {
        return $this->mediaId;
    }

    public function setMediaId(?string $mediaId): void
    {
        $this->mediaId = $mediaId;
    }

    public function getThumbnailMediaId(): ?string
    {
        return $this->thumbnailMediaId;
    }

    public function setThumbnailMediaId(?string $thumbnailMediaId): void
    {
        $this->thumbnailMediaId = $thumbnailMediaId;
    }

    public function getLanguageId(): ?string
    {
        return $this->languageId;
    }

    public function setLanguageId(?string $languageId): void
    {
        $this->languageId = $languageId;
    }

    public function getProduct(): ?ProductEntity
    {
        return $this->product;
    }

    public function setProduct(?ProductEntity $product): void
    {
        $this->product = $product;
    }

    public function getMedia(): ?MediaEntity
    {
        return $this->media;
    }

    public function setMedia(?MediaEntity $media): void
    {
        $this->media = $media;
    }

    public function getThumbnailMedia(): ?MediaEntity
    {
        return $this->thumbnailMedia;
    }

    public function setThumbnailMedia(?MediaEntity $thumbnailMedia): void
    {
        $this->thumbnailMedia = $thumbnailMedia;
    }

    public function getLanguage(): ?MediaEntity
    {
        return $this->language;
    }

    public function setLanguage(?MediaEntity $language): void
    {
        $this->language = $language;
    }
}
