<?php declare(strict_types=1);

namespace Oxoloaivideo\Migration;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Exception;
use Shopware\Core\Framework\Migration\MigrationStep;

class Migration1679405146CreateOxoloMedia extends MigrationStep
{
    public function getCreationTimestamp(): int
    {
        return 1679405146;
    }

    /**
     * @throws Exception
     */
    public function update(Connection $connection): void
    {
        $query = <<<SQL
            CREATE TABLE IF NOT EXISTS `oxoloaivideo_media` (
                `id` BINARY(16) NOT NULL,
                `oxolo_id` VARCHAR(255) NOT NULL,
                `media_id` BINARY(16) NULL,
                `created_at` DATETIME(3) NOT NULL,
                `updated_at` DATETIME(3) NULL,

                PRIMARY KEY (`id`),
                INDEX `idx.oxoloaivideo_media.oxolo_id` (`oxolo_id`),

                CONSTRAINT `uniq.oxoloaivideo_media.oxolo_id`
                    UNIQUE (`oxolo_id`),
                CONSTRAINT `uniq.oxoloaivideo_media.media_id`
                    UNIQUE (`media_id`),
                CONSTRAINT `fk.oxoloaivideo_media.media_id`
                    FOREIGN KEY (`media_id`)
                    REFERENCES `media` (`id`)
                    ON DELETE SET NULL
                    ON UPDATE CASCADE
            )
            ENGINE = InnoDB
            DEFAULT CHARSET = utf8mb4
            COLLATE = utf8mb4_unicode_ci;
        SQL;

        $connection->executeStatement($query);
    }

    public function updateDestructive(Connection $connection): void
    {
    }
}
