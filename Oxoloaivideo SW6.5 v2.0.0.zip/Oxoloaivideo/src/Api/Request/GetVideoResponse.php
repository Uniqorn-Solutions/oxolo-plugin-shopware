<?php declare(strict_types=1);

namespace Oxoloaivideo\Api\Request;

class GetVideoResponse
{
    public function __construct(
        private ?string $link,
        private ?string $thumbnail,
        private string $status,
    ) {
    }

    public function getLink(): ?string
    {
        return $this->link;
    }

    public function setLink(?string $link): void
    {
        $this->link = $link;
    }

    public function getThumbnail(): ?string
    {
        return $this->thumbnail;
    }

    public function setThumbnail(?string $thumbnail): void
    {
        $this->thumbnail = $thumbnail;
    }

    public function getStatus(): string
    {
        return $this->status;
    }

    public function setStatus(string $status): void
    {
        $this->status = $status;
    }
}
