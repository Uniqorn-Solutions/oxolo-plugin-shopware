<?php declare(strict_types=1);

namespace Oxoloaivideo\Webhook\Controller;

use Oxoloaivideo\Webhook\Service\WebhookService;
use Shopware\Core\Framework\Context;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route(defaults: ['_routeScope' => ['api']])]
class WebhookController extends AbstractController
{
    public function __construct(private readonly WebhookService $webhookService)
    {
    }

    #[Route(
        path: '/api/_action/oxoloaivideo/webhook',
        name: 'api.action.oxoloaivideo.webhook',
        defaults: ['auth_required' => false],
        methods: ['POST']
    )]
    public function handleWebhook(Request $request, Context $context): Response
    {
        $this->webhookService->handleNotification($request, $context);

        return new Response(null, Response::HTTP_NO_CONTENT);
    }
}
