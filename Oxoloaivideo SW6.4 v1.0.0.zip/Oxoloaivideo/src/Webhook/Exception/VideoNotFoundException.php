<?php declare(strict_types=1);

namespace Oxoloaivideo\Webhook\Exception;

use Shopware\Core\Framework\ShopwareHttpException;
use Symfony\Component\HttpFoundation\Response;

class VideoNotFoundException extends ShopwareHttpException
{
    private string $oxoloVideoId;

    public function __construct(string $oxoloVideoId)
    {
        $this->oxoloVideoId = $oxoloVideoId;

        parent::__construct(
            'Video with Oxolo ID {{ oxoloVideoId }} not found.',
            ['oxoloVideoId' => $oxoloVideoId]
        );
    }

    public function getOxoloVideoId(): string
    {
        return $this->oxoloVideoId;
    }

    public function getErrorCode(): string
    {
        return 'OXOLOAIVIDEO__VIDEO_NOT_FOUND';
    }

    public function getStatusCode(): int
    {
        return Response::HTTP_BAD_REQUEST;
    }
}
