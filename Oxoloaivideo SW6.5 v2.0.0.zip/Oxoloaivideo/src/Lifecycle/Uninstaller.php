<?php declare(strict_types=1);

namespace Oxoloaivideo\Lifecycle;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Exception;

class Uninstaller
{
    public function __construct(private readonly Connection $connection)
    {
    }

    /**
     * @throws Exception
     */
    public function uninstall(): void
    {
        $this->connection->executeStatement('DROP TABLE IF EXISTS `oxoloaivideo_video`');
        $this->connection->executeStatement('DROP TABLE IF EXISTS `oxoloaivideo_media`');
    }
}
