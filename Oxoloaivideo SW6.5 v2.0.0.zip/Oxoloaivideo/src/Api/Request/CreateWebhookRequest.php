<?php declare(strict_types=1);

namespace Oxoloaivideo\Api\Request;

class CreateWebhookRequest
{
    public function __construct(
        private readonly string $url,
        private readonly string $token,
    ) {
    }

    public function toArray(): array
    {
        return [
            'webhook_url' => $this->url,
            'webhook_url_method' => 'post',
            'token' => $this->token,
            'meta' => [],
        ];
    }
}
