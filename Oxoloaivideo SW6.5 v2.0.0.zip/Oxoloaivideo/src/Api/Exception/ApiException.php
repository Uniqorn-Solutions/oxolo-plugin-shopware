<?php declare(strict_types=1);

namespace Oxoloaivideo\Api\Exception;

use Oxoloaivideo\Exception\OxoloException;

class ApiException extends OxoloException
{
}
