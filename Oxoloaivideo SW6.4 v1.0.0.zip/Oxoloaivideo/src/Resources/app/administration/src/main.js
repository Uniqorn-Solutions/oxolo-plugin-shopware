import './init/service.init';
import './module/extension/sw-product/component/oxoloaivideo-catalog-preview';
import './module/extension/sw-product/page/sw-product-detail';
import './module/extension/sw-product/view/sw-product-detail-oxoloaivideo';

Shopware.Module.register('sw-product-detail-oxoloaivideo-extension', {
    routeMiddleware(next, currentRoute) {
        if (currentRoute.name === 'sw.product.detail') {
            currentRoute.children.push({
                name: 'sw.product.detail.oxoloaivideo',
                path: '/sw/product/detail/:id/oxoloaivideo',
                component: 'sw-product-detail-oxoloaivideo',
                meta: {
                    parentPath: "sw.product.index"
                }
            });
        }
        next(currentRoute);
    }
});
