<?php declare(strict_types=1);

namespace Oxoloaivideo\Lifecycle;

use Shopware\Core\System\SystemConfig\SystemConfigService;

class Installer
{
    private SystemConfigService $systemConfigService;

    public function __construct(SystemConfigService $systemConfigService)
    {
        $this->systemConfigService = $systemConfigService;
    }

    public function install(): void
    {
        $this->createWebhookToken();
    }

    private function createWebhookToken(): void
    {
        $token = $this->systemConfigService->get('Oxoloaivideo.config.webhookToken');

        if (!$token) {
            $token = bin2hex(random_bytes(64));
            $this->systemConfigService->set('Oxoloaivideo.config.webhookToken', $token);
        }
    }
}
