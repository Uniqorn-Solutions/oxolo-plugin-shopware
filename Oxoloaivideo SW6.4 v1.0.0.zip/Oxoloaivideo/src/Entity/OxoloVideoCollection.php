<?php declare(strict_types=1);

namespace Oxoloaivideo\Entity;

use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;

/**
 * @method void                  add(OxoloVideoEntity $entity)
 * @method void                  set(string $key, OxoloVideoEntity $entity)
 * @method OxoloVideoEntity[]    getIterator()
 * @method OxoloVideoEntity[]    getElements()
 * @method OxoloVideoEntity|null get(string $key)
 * @method OxoloVideoEntity|null first()
 * @method OxoloVideoEntity|null last()
 */
class OxoloVideoCollection extends EntityCollection
{
    protected function getExpectedClass(): string
    {
        return OxoloVideoEntity::class;
    }
}
