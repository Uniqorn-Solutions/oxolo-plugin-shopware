<?php declare(strict_types=1);

namespace Oxoloaivideo\Webhook\MesssageQueue;

use Exception;
use Oxoloaivideo\Entity\OxoloVideoEntity;
use Oxoloaivideo\Service\Exception\VideoExistsException;
use Oxoloaivideo\Service\VideoDownloader;
use Psr\Log\LoggerInterface;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\MessageQueue\Handler\AbstractMessageHandler;

class DownloadOxoloVideoHandler extends AbstractMessageHandler
{
    private VideoDownloader $videoDownloader;
    private EntityRepository $videoRepository;
    private LoggerInterface $logger;

    public function __construct(
        VideoDownloader $videoDownloader,
        EntityRepository $videoRepository,
        LoggerInterface $logger
    ) {
        $this->videoDownloader = $videoDownloader;
        $this->videoRepository = $videoRepository;
        $this->logger = $logger;
    }

    /**
     * @param DownloadOxoloVideo $message
     * @throws Exception
     */
    public function handle($message): void
    {
        $context = Context::createDefaultContext();
        $video = $this->getVideo($message->getVideoId(), $context);

        if (!$video) {
            $this->logger->error(
                'Couldn\'t download video. Video with ID {videoId} not found.',
                [
                    'videoId'=> $message->getVideoId(),
                    'oxoloVideoId' => $message->getOxoloVideoId(),
                ]
            );

            return;
        }

        try {
            $this->videoDownloader->downloadVideo($video, $context);
        } catch (VideoExistsException $exception) {
            return;
        } catch (Exception $exception) {
            $this->logger->error(
                'Download process for video with Oxolo ID {oxoloVideoId} failed. ' . $exception,
                ['oxoloVideoId' => $video->getOxoloId()],
            );

            throw $exception;
        }
    }

    public static function getHandledMessages(): iterable
    {
        return [DownloadOxoloVideo::class];
    }

    private function getVideo(string $videoId, Context $context): ?OxoloVideoEntity
    {
        $criteria = new Criteria([$videoId]);

        return $this->videoRepository->search($criteria, $context)->first();
    }
}
