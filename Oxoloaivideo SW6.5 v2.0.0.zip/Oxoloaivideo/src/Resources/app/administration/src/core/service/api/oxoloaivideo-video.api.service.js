const ApiService = Shopware.Classes.ApiService;

class OxoloaivideoVideoService extends ApiService {
    constructor(httpClient, loginService, apiEndpoint = 'oxoloaivideo') {
        super(httpClient, loginService, apiEndpoint);
    }

    checkProgress(productId) {
        const headers = this.getBasicHeaders();

        return this.httpClient
            .get(
                `_action/${this.getApiBasePath()}/check-progress/${productId}`,
                { headers }
            )
            .then((response) => {
                return ApiService.handleResponse(response);
            });
    }

    create(productId, actorId, musicId, templateId, voiceId, description) {
        const headers = this.getBasicHeaders();

        return this.httpClient
            .post(
                `_action/${this.getApiBasePath()}/create-video`,
                { productId, actorId, musicId, templateId, voiceId, description },
                { headers }
            )
            .then((response) => {
                return ApiService.handleResponse(response);
            });
    }

    download(productId) {
        const headers = this.getBasicHeaders();

        return this.httpClient
            .get(
                `_action/${this.getApiBasePath()}/download-videos/${productId}`,
                { headers }
            )
            .then((response) => {
                return ApiService.handleResponse(response);
            });
    }

    getBasicHeaders() {
        return {
            ...super.getBasicHeaders(),
            'sw-language-id': Shopware.Context.api.languageId,
        };
    }
}

export default OxoloaivideoVideoService;
