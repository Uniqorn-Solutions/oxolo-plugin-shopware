<?php declare(strict_types=1);

namespace Oxoloaivideo\Exception;

use Exception;

/**
 * Parent class for all plugin exceptions.
 */
class OxoloException extends Exception
{
}
