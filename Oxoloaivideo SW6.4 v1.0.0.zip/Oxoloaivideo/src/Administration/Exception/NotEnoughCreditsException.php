<?php declare(strict_types=1);

namespace Oxoloaivideo\Administration\Exception;

use Shopware\Core\Framework\ShopwareHttpException;
use Symfony\Component\HttpFoundation\Response;

class NotEnoughCreditsException extends ShopwareHttpException
{
    private int $availableCredits;

    public function __construct(int $availableCredits)
    {
        $this->availableCredits = $availableCredits;

        parent::__construct(
            'You don\'t have enough credits. Available credits: {{ availableCredits }}.',
            ['availableCredits' => $availableCredits]
        );
    }

    public function getAvailableCredits(): int
    {
        return $this->availableCredits;
    }

    public function getErrorCode(): string
    {
        return 'OXOLOAIVIDEO__NOT_ENOUGH_CREDITS';
    }

    public function getStatusCode(): int
    {
        return Response::HTTP_PAYMENT_REQUIRED;
    }
}
