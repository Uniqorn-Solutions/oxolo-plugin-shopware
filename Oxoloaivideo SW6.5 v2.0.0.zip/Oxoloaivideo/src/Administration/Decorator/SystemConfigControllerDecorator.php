<?php declare(strict_types=1);

namespace Oxoloaivideo\Administration\Decorator;

use Shopware\Core\Framework\Context;
use Oxoloaivideo\Api\Exception\ApiException;
use Oxoloaivideo\Webhook\Service\WebhookService;
use Shopware\Core\System\SystemConfig\Api\SystemConfigController;
use Shopware\Core\System\SystemConfig\Service\ConfigurationService;
use Shopware\Core\System\SystemConfig\SystemConfigService;
use Shopware\Core\System\SystemConfig\Validation\SystemConfigValidator;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

#[Route(defaults: ['_routeScope' => ['api']])]
class SystemConfigControllerDecorator extends SystemConfigController
{
    public function __construct(
        private readonly SystemConfigController $decorated,
        ConfigurationService $configurationService,
        SystemConfigService $systemConfig,
        SystemConfigValidator $systemConfigValidator,
        private readonly WebhookService $webhookService,
    ) {
        parent::__construct($configurationService, $systemConfig, $systemConfigValidator);
    }

    /**
     * @throws ApiException
     */
    public function batchSaveConfiguration(Request $request, ?Context $context = null): JsonResponse
    {
        $response = $this->decorated->batchSaveConfiguration($request);

        $allParams = $request->request->all();

        if (str_starts_with((string) array_key_first(reset($allParams)), 'Oxoloaivideo')) {
            $this->webhookService->createWebhook();
        }

        return $response;
    }
}
