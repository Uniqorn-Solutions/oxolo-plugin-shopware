import './sw-product-detail-oxoloaivideo.scss';
import template from './sw-product-detail-oxoloaivideo.html.twig';

const { mapState } = Shopware.Component.getComponentHelper();

Shopware.Component.register('sw-product-detail-oxoloaivideo', {
    template,

    inject: [
        'oxoloaivideoCatalogService',
        'oxoloaivideoVideoService',
    ],

    mixins: [
        'notification',
    ],

    metaInfo() {
        return {
            title: 'Oxolo'
        };
    },

    data() {
        return {
            createForm: {
                actorId: '',
                musicId: '',
                templateId: '',
                voiceId: '',
                description: '',
            },
            actors: [],
            musics: [],
            templates: [],
            voices: [],
            isLoading: true,
            isCreatingVideo: false,
            isVideoCreated: false,
            isCheckingProgress: false,
            isDownloadingVideo: false,
            isVideoDownloaded: false,
            videosInProgress: 0,
            videosToDownload: 0,
        };
    },

    computed: {
        ...mapState('swProductDetail', [
            'product',
            'parentProduct',
        ]),
    },

    mounted() {
        this.loadCatalogs();
        this.setDescription();

        if (this.product.id) {
            this.checkProgress();
        }
    },

    watch: {
        'product.id': {
            handler() {
                this.checkProgress();
            },
        },
        product() {
            this.setDescription();
            this.loadCatalogs();
        },
        parentProduct() {
            this.setDescription();
        },
    },

    methods: {
        loadCatalogs() {
            this.actors = [];
            this.musics = [];
            this.templates = [];
            this.voices = [];

            this.oxoloaivideoCatalogService.getCatalogs('actor')
                .then((response) => {
                    this.actors = response.catalogs;
                });
            this.oxoloaivideoCatalogService.getCatalogs('music')
                .then((response) => {
                    this.musics = response.catalogs;
                });
            this.oxoloaivideoCatalogService.getCatalogs('template')
                .then((response) => {
                    this.templates = response.catalogs;
                });
            this.oxoloaivideoCatalogService.getCatalogs('voice')
                .then((response) => {
                    this.voices = response.catalogs;
                });
        },

        checkProgress() {
            this.isCheckingProgress = true;

            this.oxoloaivideoVideoService.checkProgress(this.product.id)
                .then((response) => {
                    this.videosToDownload = response.toDownload;
                    this.videosInProgress = response.inProgress;

                    this.isCheckingProgress = false;
                    this.isLoading = false;
                })
                .catch((errorResponse) => {
                    if (errorResponse.response.data && errorResponse.response.data.errors) {
                        let message = this.$tc('sw-product-detail-oxoloaivideo.message.checkProgressError') + ' '
                            + errorResponse.response.data.errors.map((error) => {
                                return error.detail;
                            }).join(' / ');

                        this.createNotificationError({
                            message: message,
                        });
                    }

                    this.isCheckingProgress = false;
                    this.isLoading = false;
                });
        },

        createVideo() {
            this.isCreatingVideo = true;

            this.oxoloaivideoVideoService.create(
                this.product.id,
                this.createForm.actorId,
                this.createForm.musicId,
                this.createForm.templateId,
                this.createForm.voiceId,
                this.createForm.description,
            ).then((response) => {
                this.createNotificationSuccess({
                    message: this.$tc('sw-product-detail-oxoloaivideo.message.createVideoSuccess'),
                });

                this.isCreatingVideo = false;
                this.isVideoCreated = true;
                this.checkProgress();
            }).catch((errorResponse) => {
                if (errorResponse.response.data && errorResponse.response.data.errors) {
                    let message = this.$tc('sw-product-detail-oxoloaivideo.message.createVideoError') + ' '
                        + errorResponse.response.data.errors.map((error) => {
                            return error.detail;
                        }).join(' / ');

                    this.createNotificationError({
                        message: message,
                    });
                }

                this.isCreatingVideo = false;
                this.isVideoCreated = false;
                this.checkProgress();
            });
        },

        downloadVideos() {
            this.isDownloadingVideo = true;

            this.oxoloaivideoVideoService.download(
                this.product.id,
            ).then((response) => {
                const downloaded = response.downloaded;
                const inProgress = response.inProgress;
                const failed = response.failed;

                let message = '';

                if (failed) {
                    message += this.$tc('sw-product-detail-oxoloaivideo.message.failedVideos', failed) + ' ';
                }
                if (downloaded) {
                    message += this.$tc('sw-product-detail-oxoloaivideo.message.downloadedVideos', downloaded) + ' ';
                }
                if (inProgress) {
                    message += this.$tc('sw-product-detail-oxoloaivideo.message.inProgressVideos', inProgress);
                }

                this.isDownloadingVideo = false;

                if (failed) {
                    this.createNotificationError({message: message});
                    this.isVideoDownloaded = false;
                } else if (downloaded) {
                    this.createNotificationSuccess({message: message});
                    this.isVideoDownloaded = true;
                    this.$root.$emit('product-reload');
                } else if (inProgress) {
                    this.createNotificationInfo({message: message});
                    this.isVideoDownloaded = false;
                } else {
                    this.createNotificationInfo({
                        message: this.$tc('sw-product-detail-oxoloaivideo.message.noVideosToDownload'),
                    });
                    this.isVideoDownloaded = false;
                }

                this.checkProgress();
            }).catch((errorResponse) => {
                if (errorResponse.response.data && errorResponse.response.data.errors) {
                    const message = this.$tc('sw-product-detail-oxoloaivideo.message.downloadError') + ' '
                        + errorResponse.response.data.errors.map((error) => {
                            return error.detail;
                        }).join(' / ');

                    this.createNotificationError({
                        message: message,
                    });
                }

                this.isDownloadingVideo = false;
                this.isVideoDownloaded = false;
                this.checkProgress();
            });
        },

        setDescription() {
            if (this.product.description) {
                this.createForm.description = this.stripHtml(this.product.description);
            } else if (this.parentProduct.description) {
                this.createForm.description = this.stripHtml(this.parentProduct.description);
            } else {
                this.createForm.description = '';
            }
        },

        stripHtml(text) {
            return text.replace(/<\/?[^>]+(>|$)/g, " ");
        },
    },
});
