const ApiService = Shopware.Classes.ApiService;

class OxoloaivideoCatalogService extends ApiService {
    #cache = {};

    constructor(httpClient, loginService, apiEndpoint = 'oxoloaivideo') {
        super(httpClient, loginService, apiEndpoint);
    }

    getCatalog(catalogId) {
        if (this.#cache[catalogId]) {
            return this.#cache[catalogId];
        }

        const headers = this.getBasicHeaders();

        this.#cache[catalogId] = this.httpClient
            .get(
                `_action/${this.getApiBasePath()}/catalog/${catalogId}`,
                { headers }
            )
            .then((response) => {
                return ApiService.handleResponse(response);
            });

        return this.#cache[catalogId];
    }

    getCatalogs(filter) {
        const headers = this.getBasicHeaders();

        return this.httpClient
            .get(
                `_action/${this.getApiBasePath()}/catalogs/${filter}`,
                { headers }
            )
            .then((response) => {
                return ApiService.handleResponse(response);
            });
    }

    getBasicHeaders() {
        return {
            ...super.getBasicHeaders(),
            'sw-language-id': Shopware.Context.api.languageId,
        };
    }

    clearCache() {
        this.#cache = {};
    }
}

export default OxoloaivideoCatalogService;
