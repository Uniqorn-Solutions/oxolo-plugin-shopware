<?php declare(strict_types=1);

namespace Oxoloaivideo\Api;

use Oxoloaivideo\Api\Request\GetCatalogResponse;
use Oxoloaivideo\Service\Logger;
use Shopware\Core\Framework\Adapter\Cache\CacheValueCompressor;
use Shopware\Core\System\SystemConfig\SystemConfigService;
use Symfony\Contracts\Cache\CacheInterface;

class CachedGateway extends Gateway
{
    public function __construct(
        Logger $logger,
        SystemConfigService $systemConfigService,
        private readonly Gateway $decorated,
        private readonly CacheInterface $cache,
    ) {
        parent::__construct($logger, $systemConfigService);
    }

    public function getCatalogs(string $filter): array
    {
        $key = 'oxolo-catalogs-' . $filter;

        $catalogs = $this->cache->get($key, function () use ($filter) {
            $catalogs = $this->decorated->getCatalogs($filter);

            return CacheValueCompressor::compress($catalogs);
        });

        return CacheValueCompressor::uncompress($catalogs);
    }

    public function getCatalog(string $catalogId): GetCatalogResponse
    {
        $key = 'oxolo-catalog-' . $catalogId;

        $catalog = $this->cache->get($key, function () use ($catalogId) {
            $catalog = $this->decorated->getCatalog($catalogId);

            return CacheValueCompressor::compress($catalog);
        });

        return CacheValueCompressor::uncompress($catalog);
    }
}
