<?php declare(strict_types=1);

namespace Oxoloaivideo\Api\Request;

class CreateVideoRequest
{
    private ?string $actorId = null;
    private string $longDescription;
    /** @var string[] */
    private array $media;
    private ?string $musicId = null;
    private ?string $productCategory = null;
    private string $shopUrl;
    private string $shortDescription;
    private string $templateId;
    private string $title;
    private ?string $voiceId = null;

    public function getActorId(): ?string
    {
        return $this->actorId;
    }

    public function setActorId(?string $actorId): void
    {
        $this->actorId = $actorId;
    }

    public function getLongDescription(): string
    {
        return $this->longDescription;
    }

    public function setLongDescription(string $longDescription): void
    {
        $this->longDescription = $longDescription;
    }

    public function getMedia(): array
    {
        return $this->media;
    }

    public function setMedia(array $media): void
    {
        $this->media = $media;
    }

    public function getMusicId(): ?string
    {
        return $this->musicId;
    }

    public function setMusicId(?string $musicId): void
    {
        $this->musicId = $musicId;
    }

    public function getProductCategory(): ?string
    {
        return $this->productCategory;
    }

    public function setProductCategory(?string $productCategory): void
    {
        $this->productCategory = $productCategory;
    }

    public function getShopUrl(): string
    {
        return $this->shopUrl;
    }

    public function setShopUrl(string $shopUrl): void
    {
        $this->shopUrl = $shopUrl;
    }

    public function getShortDescription(): string
    {
        return $this->shortDescription;
    }

    public function setShortDescription(string $shortDescription): void
    {
        $this->shortDescription = $shortDescription;
    }

    public function getTemplateId(): string
    {
        return $this->templateId;
    }

    public function setTemplateId(string $templateId): void
    {
        $this->templateId = $templateId;
    }

    public function getTitle(): string
    {
        return $this->title;
    }

    public function setTitle(string $title): void
    {
        $this->title = $title;
    }

    public function getVoiceId(): ?string
    {
        return $this->voiceId;
    }

    public function setVoiceId(?string $voiceId): void
    {
        $this->voiceId = $voiceId;
    }

    public function toArray(): array
    {
        $data = [
            'long_description' => $this->longDescription,
            'media' => $this->media,
            'shop_url' => $this->shopUrl,
            'short_description' => $this->shortDescription,
            'template_id' => $this->templateId,
            'title' => $this->title,
        ];

        if ($this->actorId) {
            $data['actor_id'] = $this->actorId;
        }
        if ($this->musicId) {
            $data['music_id'] = $this->musicId;
        }
        if ($this->productCategory) {
            $data['product_category'] = $this->productCategory;
        }
        if ($this->voiceId) {
            $data['voice_id'] = $this->voiceId;
        }

        return $data;
    }
}
