<?php declare(strict_types=1);

namespace Oxoloaivideo\Entity;

use Shopware\Core\Content\Media\MediaEntity;
use Shopware\Core\Framework\DataAbstractionLayer\Entity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityIdTrait;

class OxoloMediaEntity extends Entity
{
    use EntityIdTrait;

    protected string $oxoloId;
    protected ?string $mediaId = null;

    protected ?MediaEntity $media = null;

    public function getOxoloId(): string
    {
        return $this->oxoloId;
    }

    public function setOxoloId(string $oxoloId): void
    {
        $this->oxoloId = $oxoloId;
    }

    public function getMediaId(): ?string
    {
        return $this->mediaId;
    }

    public function setMediaId(?string $mediaId): void
    {
        $this->mediaId = $mediaId;
    }

    public function getMedia(): ?MediaEntity
    {
        return $this->media;
    }

    public function setMedia(?MediaEntity $media): void
    {
        $this->media = $media;
    }
}
